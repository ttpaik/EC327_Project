package com.example.gomoku;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class information extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

    }
}
